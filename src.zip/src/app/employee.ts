export class Employee {
    employeeId: number;
    employeeName: String;
    department:String;
    address : String;
    email : String;
    phoneNumber : number;
    salary : number;

}
